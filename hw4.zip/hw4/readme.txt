I started creating my website for my resume. I linked 4 webpages together with a navbar, a list, some images and some other things all using Bootsrap CSS as well as a small stylesheet of my own. 
link: http://weblab.cs.uml.edu/~rwentzel/home.html
